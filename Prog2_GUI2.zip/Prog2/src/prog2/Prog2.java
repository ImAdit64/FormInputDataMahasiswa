package prog2;

public class Prog2 {
    
    public static void main(String[] args) {
    
}
}